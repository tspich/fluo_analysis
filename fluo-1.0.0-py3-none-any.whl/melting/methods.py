import numpy as np
from scipy.optimize import least_squares

from . import functions, constants


baseline_unbound_minT = 70
baseline_unbound_maxT = 80
baseline_bound_maxT = 20


def T_m_ds_raw(temperatures,
               ydata,
               baseline_bound_minT = -1,
               baseline_bound_maxT = 20.0,
               baseline_unbound_minT = 70,
               baseline_unbound_maxT = -1,
               debug = False):
    T = np.array(temperatures)

    # set bounds first
    bl_b_minT   = T[0] if baseline_bound_minT == -1 else baseline_bound_minT
    bl_ub_maxT  = T[-1] if baseline_unbound_maxT == -1 else baseline_unbound_maxT

    bl_b_maxT   = T[-1] if baseline_bound_maxT not in T else baseline_bound_maxT
    bl_ub_minT  = T[-1] if baseline_unbound_minT not in T else baseline_unbound_minT

    if debug:
        print(f"bounds_bound: [{bl_b_minT}, {bl_b_maxT}]")
        print(f"bounds_unbound: [{bl_ub_minT}, {bl_ub_maxT}]")

    # create upper base line (bound state)
    if bl_b_maxT == 10:
        m_bound = 0
        b_bound = ydata[0]
    else:
        m_bound, b_bound = functions.fit_linear(T, ydata, bl_b_minT, bl_b_maxT)

    # lower base line
    if bl_ub_minT >= bl_ub_maxT :
        m_unbound = 0
        b_unbound = ydata[-1]
        if debug:
            print('lower base line: ', m_unbound, b_unbound)
    else:
        m_unbound, b_unbound = functions.fit_linear(T, ydata, bl_ub_minT, bl_ub_maxT)


    # median of base lines
    m_med, b_med = (m_bound + m_unbound) / 2, (b_bound + b_unbound) / 2

    T_m, y_dat = functions.intersect_lin(m_med, b_med, T, ydata)

    return T_m, y_dat, (m_bound, b_bound), (m_unbound, b_unbound), (m_med, b_med)


def vantHoff(T,
             signal,
             m_bound,
             b_bound,
             m_unbound,
             b_unbound,
             c0,
             border = 0.1,
             T_scale = 1000.,
             duplex = True,
             t1_min = -1,
             t1_max = -1):
    # normalize signal to obtain fraction of folded
    f_folded  = [ (dd - functions.linear(T[i], m_unbound, b_unbound)) / (functions.linear(T[i], m_bound, b_bound) - functions.linear(T[i], m_unbound, b_unbound)) for i, dd in enumerate(signal) ]
    #print('f_folded', f_folded)

    K         = [ np.log(2 * ff / (c0 * ((1. - ff) ** 2))) if ff <= (1 - border) and ff >= border else None for ff in f_folded ]
    t1        = [ T_scale / (t - constants.T0) for t in T ]
    

    lnK = []
    tt  = []

    # compile actual data without None values
    #print('k')
    for i in range(0, len(K)):
        #print(i,t1[i], K[i])
        if K[i] != None:
            tt.append(t1[i])
            lnK.append(K[i])

    #print('lnk: ', min(lnK), max(lnK))
    #print('tt: ', min(tt), max(tt))

    #print('t1_min: ', t1_min)
    #for i, v in enumerate(tt):
    #    print(i,v, (T_scale/v)+constants.T0)
    #    if T_scale/v+constants.T0 <= t1_min:
    #        print('\t\t', i, v)

    if t1_min == -1:
        t1_min = len(t1)
    else:
        #print([(i, v) for i,v in enumerate(tt) if v < t1_min])
        t1_min = next(i for i,v in enumerate(tt) if v < t1_min)
        #[i for i,v in enumerate(tt) if T_scale/v+constants.T0 < t1_min][-1] 

    #print('\n\n')

    #print('t1_max: ', t1_max)
    #for i, v in enumerate(tt):
    #   if T_scale/v+constants.T0 <= t1_max:
    #       print(i, v, T_scale/v+constants.T0)

    if t1_max == -1:
        t1_max = 0
    else:
        #print([i for i,v in enumerate(tt) if T_scale/v+constants.T0 <= t1_max])
        t1_max = next(i for i,v in enumerate(tt) if v <= t1_max)
        #[i for i,v in enumerate(tt) if T_scale/v+constants.T0 <= t1_max][-1] 

    #print(t1_min, t1_max)#, len(tt), tt)

    xdata = np.array(tt[t1_max:t1_min])
    ydata = np.array(lnK[t1_max:t1_min])

    #print('xdata\n', xdata)
    #print('\n\nydata\n', ydata)

    res_lsq = least_squares(functions.linear_res,
                            [1, 1],
                            args=(xdata, ydata))

    t_m = (np.log(4 / c0) - res_lsq.x[1]) / res_lsq.x[0]
    T_m = T_scale / t_m + constants.T0
    dH  = -res_lsq.x[0] * constants.R * T_scale
    dG_Tm = constants.R * (T_m - constants.T0) * np.log(4 / c0) + dH

    dS    = dH / (T_m - constants.T0) + constants.R * np.log(4 / c0)
    dG_37 = dH - (37. - constants.T0) * dS

    return T_m, dG_37, dH, dS, t1, K, xdata, ydata, res_lsq.x


def fit_full_function(T, d, c0 = 1e-6, dH_init = -100, dS_init = -0.2, lin_init = 20, max_v=np.inf):
    xdata = np.array(T)
    ydata = np.array(d)


    # use the first and last lin_init data values
    # for initializing the linear intercepts of L_1 and L_2
    b1_init = sum(d[0:lin_init]) / lin_init
    b2_init = sum(d[-lin_init:]) / lin_init
    
    #print('lin_init = ', lin_init)
    #print(d[0: lin_init])
    #print('b1 b2 init: ', b1_init, b2_init)

    x_init = np.array([dH_init, dS_init, 0, b1_init, 0, b2_init])  # dH, dS, m1, b1, m2, b2
    bounds = ([ -150, -5,       0, -np.inf, 0,      -np.inf ],
              [0,      0,  np.inf,  np.inf, np.inf, max_v])

    scales  = [1., 0.01, 0.1, 10, 0.1, 10]

    res_lsq = least_squares(functions.full_function_res,
                            x_init,
                            bounds = bounds,
                            max_nfev = 1e12,
                            gtol = 1e-8,
                            ftol = 1e-8,
                            x_scale = scales,
#                            loss='soft_l1',
#                            f_scale=0.1,
#                            jac = "3-point",
#                            method = "dogbox",
#                            verbose = 2,
                            args = (xdata, ydata),
                            kwargs = { 'c0': c0 })

    #print(res_lsq.x)
    dG_37 = res_lsq.x[0] - (37 - constants.T0) * res_lsq.x[1]
    #print(dG_37)
    dH, dS, m_b, b_b, m_ub, b_ub = res_lsq.x
    dG_37 = dH - (37. - constants.T0) * dS

    # median of base lines
    m_med, b_med = (m_b + m_ub) / 2, (b_b + b_ub) / 2

    T_m, y_dat = functions.intersect_lin(m_med, b_med, xdata, ydata)

    #print(dG_37, dH, dS, T_m, y_dat, (m_b, b_b), (m_ub, b_ub), (m_med, b_med))
    return dG_37, dH, dS, T_m, y_dat, (m_b, b_b), (m_ub, b_ub), (m_med, b_med)
