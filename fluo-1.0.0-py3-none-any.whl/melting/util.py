import os
from melting import methods, plots, functions
from melting.results_class import Results
import RNA
import numpy as np
#import matplotlib.pyplot as plt
from matplotlib.figure import Figure

default_baseline_fit = [20, 70]

raw_baseline_fit = {}
default_vH = [-1,-1]

raw_vH = {}
fit_dH = {}

border_vH = {}
raw_cut_fit = {}

def store_results(strands,
                  oligo_c,
                  salt_c,
                  plate = None,
                  duplex = None,
                  report = None,
                  T_m_raw = None,
                  T_m_vH = None,
                  T_m_fit = None,
                  dG_37_vH = None,
                  dH_vH = None,
                  dS_vH = None,
                  dG_37_fit = None,
                  dH_fit = None,
                  dS_fit = None,
                  data = None
                 ):


    #if data.exists(strands, oligo_c, salt_c):
    data.update_strand(strands,
                       oligo_c,
                       salt_c,
                       plate,
                       duplex,
                       report,
                       T_m_raw,
                       T_m_vH,
                       T_m_fit,
                       dG_37_vH,
                       dH_vH,
                       dS_vH,
                       dG_37_fit,
                       dH_fit,
                       dS_fit)


def analyze(strands, salt_c, oligo_c, plate, duplex, store_cb = None, store_data = None, input = None, T=np.arange(5,85.5, 0.5), report=None, output_dir = '.', filt = [], plot=True):

    s1, s2 = strands.split('-')

    if type(input) == list:
        d = input
    elif duplex == 'empty':
        d = np.array(input[strands][plate]['dsRNA'][salt_c][oligo_c])-np.array(input[strands][plate][duplex][salt_c][oligo_c])
        duplex = 'dsRNA-empty'
    elif plate in input[strands].keys():
        d = input[strands][plate][duplex][salt_c][oligo_c]
    else:        
        d = input[strands][salt_c][oligo_c]

    replicates = len(d)

    min_x = 0
    max_x = 100
    for rep, data in enumerate(d):
        if rep == 0:
            min_v = min(data)
            max_v = max(data)
        if min(data) < min_v:
            min_v = min(data)
        if max(data) > max_v:
            max_v = max(data)
        
    
    max_value = max_v
    min_v = min_v - 200
    max_v = max_v + 200
    
    rep = 0
    #i=0
    #while i < replicates/4:
    if plot:
        fig = Figure(figsize=(40, 12))
        axs = fig.subplots(2, 7, sharex = False, sharey = False)
        #plt.subplots(2, 7, sharex = False, sharey = False, figsize = (40, 12))
    #for _, data in enumerate(d):
    #rep_r = 0
    #while rep_r < 4:
    for rep_r in range(0, replicates):
        if rep >= len(d):
            break
        #if rep in filt:
        #    rep +=1
        #    continue
        
        
        key1 = "{}_{}_{}_{}_{}".format(strands, duplex, salt_c, oligo_c, rep)
        key2 = "{}_{}_{}_{}".format(strands, salt_c, oligo_c, rep)
        #if key1 in to_filter or key2 in to_filter:
        #    rep +=1
        #    #rep_r +=1
        #    #i+=1
        #    continue
        
        
        if type(d[rep]) is not list():
            data = list(d[rep])
        else:
            data = d[rep]

        r_data = data

        TT = np.array(T) #T[:len(data)]
        
        c0 = 1e-6 * oligo_c*2
        # 1. process raw RFU data
        # 1.1 intersection of median with base lines
        #key = "{}_{}_{}_{}".format(strands, salt_c, oligo_c, rep)
        
        if key1 in raw_baseline_fit:
            r_base_b_maxT, r_base_ub_minT = raw_baseline_fit[key1]
        elif key2 in raw_baseline_fit:
            r_base_b_maxT, r_base_ub_minT = raw_baseline_fit[key2]
        else:
            r_base_b_maxT, r_base_ub_minT = default_baseline_fit

        if key1 in raw_cut_fit:
            start, end = raw_cut_fit[key1]
        elif key2 in raw_cut_fit:
            start, end = raw_cut_fit[key2]
        else:
            start, end = [T[0], T[len(T)-1]] # [5, 85]#
        
        pos_start = np.where(TT == start)[0][0]
        pos_end   = np.where(TT == end)[0][0]+1

        TT = TT[pos_start:pos_end]
        
        #pos_m_diff = np.where(TT == r_base_ub_minT)[0][0]
        #mean_diff = np.mean(np.asarray(ss_data[rep][pos_m_diff:pos_end])-np.asarray(data[pos_m_diff:pos_end]))
        
        #if strands not in diff_ds_ss:
        #    diff_ds_ss[strands] = {}
        #if oligo_c not in diff_ds_ss[strands]:
        #    diff_ds_ss[strands][oligo_c] = {}
        #if duplex not in diff_ds_ss[strands][oligo_c]:
        #    diff_ds_ss[strands][oligo_c][duplex] = []
        #diff_ds_ss[strands][oligo_c][duplex].append(mean_diff)
        
        
        
        data = data[pos_start:pos_end]
        

        T_m_r, y_r, base_b_r, base_ub_r, base_med_r = methods.T_m_ds_raw(TT,
                                                                         data,
                                                                         baseline_bound_maxT=r_base_b_maxT,
                                                                         baseline_unbound_minT=r_base_ub_minT,
                                                                         #debug=True
                                                                        )

        # 1.2 van't Hoff analysis with base lines
        if key1 in raw_vH:
            t1_min, t1_max = raw_vH[key1]
        elif key2 in raw_vH:
            t1_min, t1_max = raw_vH[key2]
        else:
            t1_min, t1_max = default_vH


        if key1 in border_vH:
            border = border_vH[key1]
        elif key2 in border_vH:
            border = border_vH[key2]
        else:
            border = 0.15
        T_m, dG_37, dH, dS, t1, K, xdata, ydata, fit_vh = methods.vantHoff(TT,
                                                                           data,
                                                                           *base_b_r,
                                                                           *base_ub_r,
                                                                           c0,
                                                                           border = border,
                                                                           t1_min = t1_min,
                                                                           t1_max = t1_max)

        # 2. fit the flourescence data to a full function with dH and dS
        if key1 in fit_dH:
            dH_init = fit_dH[key1]
        elif key2 in fit_dH:
            dH_init = fit_dH[key2]
        else:
            dH_init = -80

        dG_37_f, dH_f, dS_f, T_m_f, y_f, base_b_f, base_ub_f, base_med_f = methods.fit_full_function(TT,
                                                                                                     data,
                                                                                                     c0=c0, # should always be oligo_c dependent?
                                                                                                     dH_init = dH_init,
                                                                                                     #max_v = max_value
                                                                                                    )

        # compute list of predicted flourescence data points according to function fit
        fit = np.array([ functions.full_function(tt, dH_f, dS_f, *base_b_f, *base_ub_f, c0=c0) for tt in TT ])

        # 3. Store results
        if store_cb:
            store_cb(strands = strands,
                     plate = plate,
                     duplex = duplex,
                     report = report,
                     oligo_c = oligo_c,
                     salt_c = salt_c,
                     T_m_raw = T_m_r,
                     T_m_vH = T_m,
                     T_m_fit = T_m_f,
                     dG_37_vH = dG_37,
                     dH_vH = dH,
                     dS_vH = dS,
                     dG_37_fit = dG_37_f,
                     dH_fit = dH_f,
                     dS_fit = dS_f,
                     data = store_data
                    )


        # 4. plots
        # 4.1 raw vs. fitted data        
        if plot:
            plots.plot_function_fit(axs[0, rep_r],
                                    TT,
                                    np.array(T),
                                    fit,
                                    c0,
                                    raw_data = r_data,
                                    base_bound = base_b_f,
                                    base_unbound = base_ub_f,
                                    raw_base_bound = base_b_r,
                                    raw_base_unbound = base_ub_r,
                                    melting_point = (T_m_f, y_f))

            #axs[0, rep_r].plot(TT, functions.linear(TT, *base_med_f), '--')
            axs[0, rep_r].set_ylim(min_v, max_v)
            axs[0, rep_r].set_xlim(min_x, max_x)

            axs[0, rep_r].axvline(x = start, color='black', linestyle="--", alpha=0.2)
            axs[0, rep_r].axvline(x = end, color='black', linestyle="--", alpha=0.2)

            if rep + 1 == replicates:
                axs[0, rep_r].set_title(r'{:2.2f}$\mu$M RNA / {:d}mM NaCl / {} / Average'.format(oligo_c, int(salt_c), duplex))
            else:
                axs[0, rep_r].set_title(r'{:2.2f}$\mu$M RNA / {:d}mM NaCl / {} / Replicate {:d}'.format(oligo_c, int(salt_c), duplex, rep + 1))

            plots.energy_params(axs[0, rep_r], T[0] + 0.5, fit[0] + (fit[-1]-fit[0])/2, dG_37_f, dH_f, dS_f)
            axs[0,rep_r].legend(loc = 'upper left', fontsize = 10)

            # 4.2 van't Hoff on raw data
            plots.plot_vantHoff(axs[1, rep_r], t1, K, c0, xdata, ydata, fit_vh, T_m)#, K_min = 10, K_max=20)

            #plots.energy_params(axs[1, rep], t1[-1] + 0.5, np.log(4 / c0), dG_37, dH, dS)
            plots.energy_params(axs[1, rep_r], 3., 10, dG_37, dH, dS)

            axs[1, rep_r].legend(loc = 'upper right', fontsize = 10)
            axs[1, rep_r].set_title("van't Hoff raw data")
        rep +=1
        #rep_r +=1

    #i+=1

    if plot:
        fig.suptitle("{} {} {}".format(strands, salt_c, oligo_c))
        fig.tight_layout(rect=[0, 0.03, 1, 0.99])
        os.makedirs(output_dir, exist_ok=True)
        fig.savefig("{}/{}_{}_{}.png".format(output_dir, strands, salt_c, oligo_c), bbox_inches='tight')

# just to be on the safe side, reset to default model
RNA.cvar.temperature = 37.
RNA.cvar.dangles = 2

