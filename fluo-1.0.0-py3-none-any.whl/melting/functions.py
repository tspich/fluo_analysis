import numpy as np
from scipy.optimize import least_squares

from . import constants

def linear(x, a, b):
    return a * x + b


def linear_res(x, T, y):
    #print('linear:\n',x, '\n', T, '\n', y) 
    return linear(T, *x) - y


def fit_linear(T, d, minT, maxT):
    start = next(i for i,v in enumerate(T) if v >= minT) # TS: change > to >= to include first temperature (10.0)
    stop  = next(i for i,v in enumerate(T) if v >= maxT)

    xdata = np.array(T[start:stop + 1])
    ydata = np.array(d[start:stop + 1])

    #print(xdata)
    #print(ydata)

    res_lsq = least_squares(linear_res,
                            [1, 1],
                            args=(xdata, ydata))

    return (res_lsq.x[0], res_lsq.x[1])


def intersect_lin(m, b, xs, ys, border = 10, min_value = 0, max_value = 10000):
    """
    Find the intersection of a linear function with
    slope m and intersect b and a set of X-Y coordinates
    given in lists xs and ys.
    """
    # 1. find point closest to the data
    closest = (min_value, max_value)
    for (i, y) in enumerate(ys[border:-border], start = border):
        v = linear(xs[i], m, b)
        if y < v and ys[i + 1] >= v:
            closest = (i, abs(y - v))
            break

    # 2. perform linear interpolation
    x1, y1 = xs[closest[0]], ys[closest[0]]
    if y1 < linear(x1, m, b):
        x2, y2 = x1, y1
        x1, y1 = xs[closest[0] - 1], ys[closest[0] - 1]
    else:
        x2, y2 = xs[closest[0] + 1], ys[closest[0] + 1]

    m_int = (y2 - y1) / (x2 - x1)
    b_int = y1 - m_int * x1

    x     = (b_int - b) / (m - m_int)
    y     = linear(x, m, b)

    return x, y


def full_function(T, dH, dS, m1, b1, m2, b2, c0 = 1e-6):
    theta = theta_from_therm(T, dH, dS, c0)
    #print('theta: ', theta)
    return theta * (m1 * T + b1) + (1 - theta) * (m2 * T + b2)


def full_function_res(x, T, y, c0 = 1e-6):
    #print('full_function_res: ', x, T, y)
    #print(*x)#, m2)
    return y - full_function(T, *x, c0)

def theta_from_therm(T, dH, dS, c0 = 1e-6):
    tt    = T - constants.T0
    dG    = dH - tt * dS
#    term  = np.sqrt(c0) * np.exp(-0.5 * dG / (constants.R * tt))
#    return term / (np.sqrt(2) + term)
    term = np.sqrt(2 * c0 * np.exp(- dG / (constants.R * tt)) + 1)
    return (term - 1) / (term + 1)
