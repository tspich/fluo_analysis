from dataclasses import dataclass
from typing import List
from tabulate import tabulate
import numpy as np
import RNA
from statistics import mean, stdev
import matplotlib.pyplot as plt
import pandas as pd
from . import constants


sequences = {
        '26': 'GAAGAIACAA',
        '27': 'GAAGAGACAA',
        '28': 'GAAGACACAA',
        '29': 'GAAGAUACAA',
        '30': 'GAAGAAACAA',
        '31': 'UUGUCUCUUC',
        '32': 'UUGUGUCUUC',
        '33': 'UUGUAUCUUC',
        '34': 'UUGUUUCUUC',
        '35': 'UUGUIUCUUC',
        '36': 'GAAGUIACAA',
        '37': 'GAAGUGACAA',
        '38': 'UUGUCACUUC',
        '39': 'GAAGGIACAA',
        '40': 'GAAGGGACAA',
        '41': 'UUGUCCCUUC',
        '42': 'GAAGCIACAA',
        '43': 'GAAGCGACAA',
        '44': 'UUGUCGCUUC',
        '45': 'GAAGAIUCAA',
        '46': 'GAAGAGUCAA',
        '47': 'UUGACUCUUC',
        '48': 'GAAGAIGCAA',
        '49': 'GAAGAGGCAA',
        '50': 'UUGCCUCUUC',
        '51': 'GAAGAICCAA',
        '52': 'GAAGAGCCAA',
        '53': 'UUGGCUCUUC',
}

modified = ['26', '35', '36', '39',
            '42', '45', '48', '51']

@dataclass
class Strand_res:
    strand    : str
    plate     : str = None
    duplex    : str = None
    mod       : str = None # 'I' if self.strand.split('-')[0] in modified or self.strand.split('-')[1] in modified else '-'
    report    : str = None
    oligo_c   : float = np.nan
    salt_c    : float = np.nan
    T_m_raw   : list() = np.nan
    T_m_vH    : list() = np.nan
    T_m_fit   : list() = np.nan
    dG_37_vH  : list() = np.nan
    dH_vH     : list() = np.nan
    dS_vH     : list() = np.nan
    dG_37_fit : list() = np.nan
    dH_fit    : list() = np.nan
    dS_fit    : list() = np.nan
    cofold    : float = np.nan
    pf        : float = np.nan
    ss        : str = None
    dh_vrna   : float = np.nan #from pf
    ds_vrna   : float = np.nan #from pf
    
    def __post_init__(self):
        seq_id1, seq_id2 = self.strand.split("-")
        s1 = sequences[seq_id1]
        s2 = sequences[seq_id2]
        
        #print(s1, s2)
        cano_bases = {'a' : 'u',
                      'u' : 'a',
                      'g' : 'c',
                      'c' : 'g',
                      'A' : 'U',
                      'U' : 'A',
                      'G' : 'C',
                      'C' : 'G',}
        
        #print(fc.sequence)
        md = RNA.md()
        if self.salt_c != 1000:
            md.salt = (self.salt_c+21)/1000
            
        if seq_id1 in modified or seq_id2 in modified:
            self.mod = 'I'
            if 'I' in s1 and 'I' in s2:
                pass
            elif 'I' in s1:
                pos = s1.index('I')
                pairing_partner = s2[::-1][pos]
                unmod_s1 = s1.replace('I', cano_bases[pairing_partner])

                fc = RNA.fold_compound(f'{unmod_s1}&{s2}', md)
                fc.sc_mod_inosine([pos+1]) #fc.sc_mod(mod_par, [pos+1])
                self.ss, self.cofold = fc.mfe()
                _, self.pf = fc.pf()

                # Get dH from VRNA
                md_36 = RNA.md(36)
                if self.salt_c != 1000:
                    md_36.salt = (self.salt_c+21)/1000
                fc_36 = RNA.fold_compound(f'{unmod_s1}&{s2}', md_36)
                fc_36.sc_mod_inosine([pos+1])
                _, pf_36 = fc_36.pf()

                md_38 = RNA.md(38)
                if self.salt_c != 1000:
                    md_38.salt = (self.salt_c+21)/1000
                fc_38 = RNA.fold_compound(f'{unmod_s1}&{s2}', md_38)
                fc_38.sc_mod_inosine([pos+1])
                _, pf_38 = fc_38.pf()

                self.ds_vrna = 0.5*(pf_36-pf_38)

                self.dh_vrna = self.pf + 310.15*self.ds_vrna


            elif 'I' in s2:
                pos = s2[::-1].index('I')
                pairing_partner = s1[pos]
                unmod_s2 = s2.replace('I', cano_bases[pairing_partner])

                fc = RNA.fold_compound(f'{s1}&{unmod_s2}', md)
                fc.sc_mod_inosine([len(fc.sequence)-pos]) #fc.sc_mod(mod_par, [len(fc.sequence)-pos])
                self.ss, self.cofold = fc.mfe()
                _, self.pf = fc.pf()

                # Get dH from VRNA
                md_36 = RNA.md(36)
                if self.salt_c != 1000:
                    md_36.salt = (self.salt_c+21)/1000
                fc_36 = RNA.fold_compound(f'{s1}&{unmod_s2}', md_36)
                fc_36.sc_mod_inosine([pos+1])
                _, pf_36 = fc_36.pf()

                md_38 = RNA.md(38)
                if self.salt_c != 1000:
                    md_38.salt = (self.salt_c+21)/1000
                fc_38 = RNA.fold_compound(f'{s1}&{unmod_s2}', md_38)
                fc_38.sc_mod_inosine([pos+1])
                _, pf_38 = fc_38.pf()

                self.ds_vrna = 0.5*(pf_36-pf_38)

                self.dh_vrna = self.pf + 310.15*self.ds_vrna

        else:
            self.mod = '-'
            fc = RNA.fold_compound(f'{s1}&{s2}', md)
            self.ss, self.cofold = fc.mfe()
            _, self.pf = fc.pf()

            # Get dH from VRNA
            md_36 = RNA.md(36)
            if self.salt_c != 1000:
                md_36.salt = (self.salt_c+21)/1000
            fc_36 = RNA.fold_compound(f'{s1}&{s2}', md_36)
            _, pf_36 = fc_36.pf()

            md_38 = RNA.md(38)
            if self.salt_c != 1000:
                md_38.salt = (self.salt_c+21)/1000
            fc_38 = RNA.fold_compound(f'{s1}&{s2}', md_38)
            _, pf_38 = fc_38.pf()

            self.ds_vrna = 0.5*(pf_36-pf_38)

            self.dh_vrna = self.pf + 310.15*self.ds_vrna


    def get_val(self, col_rm):
        val = [self.strand,                                         #0
               self.oligo_c,                                        #1
               int(self.salt_c),                                    #2
               self.mod,                                            #3
               self.plate,                                          #4
               self.duplex,                                         #5
               self.report,                                         #6
               mean(self.T_m_raw),   np.std(self.T_m_raw),          #7 8
               mean(self.T_m_vH),    np.std(self.T_m_vH),           #9 10
               mean(self.T_m_fit),   np.std(self.T_m_fit),          #11 12
               mean(self.dG_37_vH),  np.std(self.dG_37_vH),         #13 14
               mean(self.dG_37_fit), np.std(self.dG_37_fit),        #15 16
               self.cofold,                                         #17
               mean(self.dG_37_fit)-self.cofold,                    #18
               mean(self.dH_vH),     np.std(self.dH_vH),            #19 20
               mean(self.dH_fit),    np.std(self.dH_fit),           #21 22
               self.dh_vrna,                                        #23
               mean(self.dS_vH),     np.std(self.dS_vH),            #24 25
               mean(self.dS_fit),    np.std(self.dS_fit),           #26 27
               self.ds_vrna,                                        #28
               self.ss]                                             #29
        return [v for v in val if val.index(v) not in col_rm]

    def __str__(self):
        return ('{}\t{:5.1f}\t{:6.1f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{:4.2f}\t{:6.2f}\t{}\t{:6.2f}\t{:6.2f}').format(self.strand, 
                                                                                                                                                                                                                 self.oligo_c,
                                                                                                                                                                                                                 self.salt_c,
                                                                                                                                                                                                                 mean(self.T_m_raw), stdev(self.T_m_raw), 
                                                                                                                                                                                                                 mean(self.T_m_vH), stdev(self.T_m_vH), 
                                                                                                                                                                                                                 mean(self.T_m_fit), stdev(self.T_m_fit), 
                                                                                                                                                                                                                 mean(self.dG_37_vH), stdev(self.dG_37_vH),
                                                                                                                                                                                                                 mean(self.dH_vH), stdev(self.dH_vH), 
                                                                                                                                                                                                                 mean(self.dS_vH), stdev(self.dS_vH), 
                                                                                                                                                                                                                 mean(self.dG_37_fit), stdev(self.dG_37_fit),
                                                                                                                                                                                                                 mean(self.dH_fit), stdev(self.dH_fit), 
                                                                                                                                                                                                                 mean(self.dS_fit), stdev(self.dS_fit),
                                                                                                                                                                                                                 self.cofold,
                                                                                                                                                                                                                 self.ss,
                                                                                                                                                                                                                 self.dh_vrna,
                                                                                                                                                                                                                 self.ds_vrna,)
    
@dataclass
class Results:
    res: list()#List[Strand_res]

    def exists(self, strand, oligo_c, salt_c, plate, duplex, report):
        for it in self.res:
            if it.strand == strand and it.oligo_c == oligo_c and it.salt_c == salt_c and it.plate == plate and it.duplex == duplex and it.report == report:
                return True
        return False
    
    def update_strand(self, strand, oligo_c, salt_c, plate, duplex, report, T_m_raw, T_m_vH, T_m_fit, dG_37_vH, dH_vH, dS_vH, dG_37_fit, dH_fit, dS_fit):
        for it in self.res:
            if it.strand == strand and it.oligo_c == oligo_c and it.salt_c == salt_c and it.plate == plate and it.duplex == duplex and it.report == report:
                it.T_m_raw.append(T_m_raw)
                it.T_m_vH.append(T_m_vH)
                it.T_m_fit.append(T_m_fit)
                it.dG_37_vH.append(dG_37_vH)
                it.dH_vH.append(dH_vH)
                it.dS_vH.append(dS_vH)
                it.dG_37_fit.append(dG_37_fit)
                it.dH_fit.append(dH_fit)
                it.dS_fit.append(dS_fit)
                break
        
        if self.exists(strand, oligo_c, salt_c, plate, duplex, report) == False:
            self.res.append(Strand_res(strand=strand,
                                       plate = plate,
                                       duplex = duplex,
                                       report = report,
                                       oligo_c=oligo_c,
                                       salt_c=salt_c,
                                       T_m_raw=[T_m_raw],
                                       T_m_vH=[T_m_vH],
                                       T_m_fit=[T_m_fit],
                                       dG_37_vH=[dG_37_vH],
                                       dH_vH=[dH_vH],
                                       dS_vH=[dS_vH],
                                       dG_37_fit=[dG_37_fit],
                                       dH_fit=[dH_fit],
                                       dS_fit=[dS_fit]))

    def plot_melt(self, ax, oc, sc):
        sorted_val = self.sort_by_tm_fit()
        for it in sorted_val.res:
            if it.oligo_c == oc and it.salt_c == sc:# and it.plate == plate and it.duplex == duplex:
                if it.plate:
                    x_val =' '.join([it.strand, it.plate, it.duplex])
                else:
                    x_val =' '.join([it.mod, it.strand])
                #print(x_val)

                raw = ax.plot(x_val, [it.T_m_raw], 'bo', label=f'$T_m$ raw')
                vh  = ax.plot(x_val, [it.T_m_vH], 'go', label=f'$T_m$ vH')
                f   = ax.plot(x_val, [it.T_m_fit], 'ro', label=f'$T_m$ fit')
        
        plt.xticks(rotation=90)
        ax.set_title(f'Melting temperatures for each duplex, {int(sc)}mM NaCl')
        ax.set_xlabel('strands')
        ax.set_ylabel("Temperature [$^\degree C$]")
        ax.legend(handles=[raw[0], vh[0], f[0]])
        
    def ener_plot_dg(self, ax, oc, sc, model=True):
        #sorted_val = self.sort_by_duplex()
        sorted_val = self.sort_by_dg_vrna()
        for it in sorted_val.res:
            if it.oligo_c == oc and it.salt_c == sc:
                x_val =' '.join([it.mod, it.strand, it.duplex])
                #dvH = ax.plot(x_val, [it.dG_37_vH], 'bo', label=f'$\Delta$G vH')
                dFit = ax.plot(x_val, [it.dG_37_fit], 'go', label=f'$\Delta$G fit')
                if model:
                    #vrna = ax.plot(it.strand, [it.cofold], 'ro', label=f'$\Delta$G RNAcofold')
                    vrna = ax.plot(x_val, [it.cofold], 'ro', label=f'$\Delta$G RNAcofold')
        
        plt.xticks(rotation=70)
        ax.set_title(f'$\Delta$G for each duplex, {int(sc)}mM NaCl')
        ax.set_xlabel('strands')
        ax.set_ylabel(f"$\Delta$G [$KCal/mol$]")
        if model:
            ax.legend(handles=[vrna[0], dFit[0]])
        else:
            ax.legend(handles=[dFit[0]])
        
        
        
        
    def sort_by_oc(self):
        return Results(sorted(self.res, key=lambda item: (item.oligo_c, item.salt_c, item.strand)))
    
    def sort_by_sc(self):
        return Results(sorted(self.res, key=lambda item: (item.salt_c, item.strand, item.oligo_c)))
    
    def sort_by_tm_raw(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.T_m_raw), item.salt_c, item.oligo_c)))
    
    def sort_by_tm_vH(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.T_m_vH), item.salt_c, item.oligo_c)))
    
    def sort_by_tm_fit(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.T_m_fit), item.salt_c, item.oligo_c)))

    def sort_by_tm_fit_err(self):
        return Results(sorted(self.res, key=lambda item: (pd.isnull(stdev(item.T_m_fit) if len(item.T_m_fit)>=2 else np.nan), stdev(item.T_m_fit) if len(item.T_m_fit)>=2 else np.nan, item.salt_c, item.oligo_c)))
    
    def sort_by_dg_vH(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dG_37_vH), item.salt_c, item.oligo_c)))
    
    def sort_by_dh_vH(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dH_vH), item.salt_c, item.oligo_c)))
    
    def sort_by_ds_vH(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dS_vH), item.salt_c, item.oligo_c)))
    
    def sort_by_dg_fit(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dG_37_fit), item.salt_c, item.oligo_c)))
    
    def sort_by_dh_fit(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dH_fit), item.salt_c, item.oligo_c)))
    
    def sort_by_ds_fit(self):
        return Results(sorted(self.res, key=lambda item: (mean(item.dS_fit), item.salt_c, item.oligo_c)))
    
    def sort_by_dg_vrna(self):
        return Results(sorted(self.res, key=lambda item: (pd.isnull(item.cofold), item.cofold, item.salt_c, item.oligo_c)))

    def sort_by_plate(self):
        return Results(sorted(self.res, key=lambda item: (item.plate, item.oligo_c, item.salt_c)))
    
    def sort_by_strand_duplex(self):
        return Results(sorted(self.res, key=lambda item: (item.strand, item.oligo_c, item.salt_c, item.duplex)))
    
    def sort_by_duplex(self):
        return Results(sorted(self.res, key=lambda item: (item.duplex, item.strand, item.oligo_c, item.salt_c)))
    
    def sort_by_err_dg_fit(self):
        return Results(sorted(self.res, key=lambda item: (pd.isnull(stdev(item.dG_37_fit) if len(item.dG_37_fit)>=2 else np.nan), stdev(item.dG_37_fit) if len(item.dG_37_fit)>=2 else np.nan, item.salt_c, item.oligo_c)))
    
                  
    def print_col(self, col_rm=[]):
        #           1         2         3        4       5        6         7      
        head = ['strand', 'oligo_c', 'salt_c', 'mod', 'plate', 'duplex', 'report',
                #   8      9      10      11      12    13 
                'T_m_raw', '', 'T_m_vH', '', 'T_m_fit', '', 
                #   14      15     16        17      18       19
                'dG_37_vH', '', 'dG_37_fit', '', 'cofold', 'diff cofold',
                #   20   21      22    23     24
                'dH_vH', '', 'dH_fit', '', 'dh_vrna',
                #   25   26     27     28     29       30
                'dS_vH', '', 'dS_fit', '', 'ds_vrna', 'ss']
        headers = [h for i, h in enumerate(head) if i not in col_rm]
        table = []
        for r in self.res:
            table.append(r.get_val(col_rm))
        return tabulate(table, headers=headers, floatfmt=".2f")
    
    def __str__(self):
          #           1         2         3        4       5        6         7      
        headers = ['strand', 'oligo_c', 'salt_c', 'mod', 'plate', 'duplex', 'report',
                #   8      9      10      11      12    13 
                'T_m_raw', '', 'T_m_vH', '', 'T_m_fit', '', 
                #   14      15     16        17      18       19
                'dG_37_vH', '', 'dG_37_fit', '', 'cofold', 'diff cofold',
                #   20   21      22    23     24
                'dH_vH', '', 'dH_fit', '', 'dh_vrna',
                #   25   26     27     28     29       30
                'dS_vH', '', 'dS_fit', '', 'ds_vrna', 'ss']
        table = []
        col_rm = []
        for r in self.res:
            table.append(r.get_val(col_rm))
        return tabulate(table, headers=headers, floatfmt=".2f")

    def get_it(self, strand, oc, sc, plate, duplex, report):
        for it in self.res:
            if it.strand == strand and it.oligo_c == oc and it.salt_c == sc and it.plate == plate and it.duplex == duplex and it.report == report:
                return it
            
    def get_all(self, id1, sc=None, oc=None):
        r = Results([])
        for it in self.res:
            if id1 in it.strand and (it.salt_c == sc or sc is None) and (it.oligo_c == oc or oc is None):
                r.res.append(it)
        return r
