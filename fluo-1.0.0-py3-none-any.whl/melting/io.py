import pandas as pd
import re

def store_ds(RFU, m, r, e, data):
    r.append(e)
    oligo_1 = m.group(1)
    oligo_2 = m.group(2)
    
    if oligo_1 > oligo_2:
        oligo_1, oligo_2 = oligo_2, oligo_1

    plate  = m.group(3)
    duplex = m.group(4)
    
    oligo_c  = float(m.group(5))
    salt_c   = float(m.group(6))

    k = oligo_1 + "-" + oligo_2

    if k not in RFU:
        RFU[k] = {}

    if plate not in RFU[k]:
        RFU[k][plate] = {}
    
    if duplex not in RFU[k][plate]:
        RFU[k][plate][duplex] = {}
        
    if salt_c not in RFU[k][plate][duplex]:
        RFU[k][plate][duplex][salt_c] = {}

    if oligo_c not in RFU[k][plate][duplex][salt_c]:
        RFU[k][plate][duplex][salt_c][oligo_c] = []

    # finally, add all data for this experiment setting
    for col in r:
        RFU[k][plate][duplex][salt_c][oligo_c].append(list(data[col]))

    r = []

    
def store_ss(RFU, m, r, e, data):
    r.append(e)
    oligo = m.group(1)
    
    plate = m.group(2)
    duplex = m.group(3)
    

    oligo_c  = float(m.group(4))
    salt_c = float(m.group(5))
    
    k = oligo

    if k not in RFU:
        RFU[k] = {}

    if plate not in RFU[k]:
        RFU[k][plate] = {}
    
    if duplex not in RFU[k][plate]:
        RFU[k][plate][duplex] = {}
        
    if salt_c not in RFU[k][plate][duplex]:
        RFU[k][plate][duplex][salt_c] = {}

    if oligo_c not in RFU[k][plate][duplex][salt_c]:
        RFU[k][plate][duplex][salt_c][oligo_c] = []

    # finally, add all data for this experiment setting
    for col in r:
        RFU[k][plate][duplex][salt_c][oligo_c].append(list(data[col]))
    r = []

def read_data(filename):
    xlsx = pd.ExcelFile(filename)
    # RFU data structure is as follows:
    #
    # RFU[helix][helix_conc][NaCl_conc][]
    #
    # where for each helix with ID 'strand_1 + "-" + strand_2',
    # total strand concentration 'helix_conc', and NaCl concentration
    # 'NaCl_conc' exists a list for each replicate that consists of
    # a list of RFU values for the temperature settings read earlier
    RFU       = {}
    # single strand measurements
    #RFU_ss    = {}

    replicate_pat = re.compile(r"^\w(\d*[\.\_]\d+|\d+)\s*$")
    avg_pat_ss = re.compile(r"^(\d+)\_(\S*)\_(\S*)\_(\d*\.\d+|\d+)\_(\d+)")
    average_pat_mu = re.compile(r"^(\d+)\+(\d+)\_(\S*)\_(\S*)\_(\d*\.\d+|\d+)\_(\d+)")

    first = True
    for sheet in xlsx.sheet_names:
        df = pd.read_excel(xlsx, sheet_name=sheet)
        if first:
            T = df['Temperature']
            first = False

        header = list(df.columns)



        r=[]
        for i, e in enumerate(header[1:], start = 1):
            m = replicate_pat.match(e)
            if m:
                r.append(e)
                continue

            m = average_pat_mu.match(e)
            if m:
                store_ds(RFU, m, r, e, df)
                r = []
                continue   

            m = avg_pat_ss.match(e)
            if m:
                store_ss(RFU, m, r, e, df)
                r = []

            else:
                r=[]

    #if ss:
    #    return T, RFU, RFU_ss

    return T, RFU
