
T0 = -273.15
R  = 1.987204e-3 # gas constant in kcal/mol

